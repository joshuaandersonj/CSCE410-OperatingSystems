/*
     File        : blocking_disk.c

     Author      : 
     Modified    : 

     Description : 

*/

/*--------------------------------------------------------------------------*/
/* DEFINES */
/*--------------------------------------------------------------------------*/

    /* -- (none) -- */

/*--------------------------------------------------------------------------*/
/* INCLUDES */
/*--------------------------------------------------------------------------*/

#include "assert.H"
#include "utils.H"
#include "console.H"
#include "blocking_disk.H"

/*--------------------------------------------------------------------------*/
/* EXTERNS */
/*--------------------------------------------------------------------------*/

extern Scheduler * SYSTEM_SCHEDULER;

/*--------------------------------------------------------------------------*/
/* Data Structures */
/*--------------------------------------------------------------------------*/

BlockingQueue::BlockingQueue()
{
	currentNode = NULL;
	tail = NULL;
	size = 0;
}
BlockingQueue::~BlockingQueue()
{
	delete currentNode;
	delete tail;
}
BlockingQueue::ThreadList::ThreadList(Thread* val)
{
	next = NULL;
	prev = NULL;
	value = val;
}
void BlockingQueue::setSize(unsigned int size_in)
{
	size = size_in;
}
BlockingQueue::ThreadList * BlockingQueue::getTail()
{
	return tail;
}
void BlockingQueue::setCurrentNode(BlockingQueue::ThreadList * newNode)
{
	currentNode = newNode;
}
void BlockingQueue::setTail(BlockingQueue::ThreadList * newTail)
{
	tail = newTail;
}

void BlockingQueue::push(Thread* pushThread)
{
	if(pushThread == NULL)
	{
		Console::puts("Error on push(Thread* pushThread). Tried to push a NULL thread");
		return;
	}
	else	
	{
		if(size == 0)
		{
			
			currentNode = new ThreadList(pushThread);
			tail = currentNode;
			++size;
			#ifdef Debug
			ThreadList *loopList = currentNode;
			Console::puts("Current Tail:");
			Console::putui(tail->value->ThreadId());
			Console::puts("Current Ready Queue:");
			for(unsigned int i = 0; i < size;++i)
			{
				
				Console::puts("Prev ThreadID:");
				Console::putui(loopList->prev->value->ThreadId());
				Console::puts("Current Value:");
				Console::putui(loopList->value->ThreadId());
				Console::puts(" ");
				Console::puts("Next ThreadID:");
				Console::putui(loopList->next->value->ThreadId());
				
				loopList = loopList->next;
			}
			Console::puts("\n");
			Console::puts("Size: ");
			Console::putui(size);
			Console::puts("\n");
			#endif
		}
		else
		{
			
			ThreadList * newTail = new ThreadList(pushThread);
			ThreadList * oldTail = tail;

			oldTail->next = newTail;
			newTail->prev = oldTail;

			tail = newTail;
			++size;
						


			/*ThreadList newNode = ThreadList(pushThread);
			tail->next = &newNode;
			ThreadList *newPrev = tail; // points to old tail
			//After next line Tail becomes the pushed Thread
			tail = tail->next;
			// Set the previous thread of the new tail to the old tail
			tail->prev = newPrev;
			//Increment the size of the queue
			++size;*/

			#ifdef Debug
			ThreadList *loopList = currentNode;
			Console::puts("Current Tail:");
			Console::putui(tail->value->ThreadId());
			Console::puts("After Push: Current Ready Queue:");
			for(unsigned int i = 0; i < size;++i)
			{
				
				
				Console::puts("Prev ThreadID:");
				Console::putui(loopList->prev->value->ThreadId());
				Console::puts("Current Value:");
				Console::putui(loopList->value->ThreadId());
				Console::puts(" ");
				Console::puts("Next ThreadID:");
				Console::putui(loopList->next->value->ThreadId());
				
				loopList = loopList->next;
			}
			Console::puts("\n");
			Console::puts("Size: ");
			Console::putui(size);
			Console::puts("\n");
			#endif
		}
	}
}
Thread * BlockingQueue::pop()
{
	if(size == 0)
	{
		Console::puts("Error on pop(). No Threads in Queue.");
	}
	else if(size == 1)
	{
		Thread * poppedThread = currentNode->value;
		tail = NULL;
		//delete currentNode;
		currentNode = NULL;
		size = 0;
		#ifdef Debug
			ThreadList *loopList = currentNode;
			Console::puts("Current Tail:");
			Console::putui(tail->value->ThreadId());
			Console::puts("After Pop ERROR SIZE IS ZERO: Current Ready Queue:");
			for(unsigned int i = 0; i < size;++i)
			{
				
				
				Console::puts("Prev ThreadID:");
				Console::putui(loopList->prev->value->ThreadId());
				Console::puts("Current Value:");
				Console::putui(loopList->value->ThreadId());
				Console::puts(" ");
				Console::puts("Next ThreadID:");
				Console::putui(loopList->next->value->ThreadId());
				
				loopList = loopList->next;
			}
			Console::puts("\n");
			Console::puts("Size: ");
			Console::putui(size);
			Console::puts("\n");
			#endif
			return poppedThread;
	}
	else
	{
		Thread* poppedThread = currentNode->value;
		currentNode = currentNode->next; //TODO::MUST FREE THE MEMORY WHEN POSSIBLE
		//delete currentNode->prev;
		currentNode->prev = NULL;
		--size;
		#ifdef Debug
			ThreadList *loopList = currentNode;
			Console::puts("Current Tail:");
			Console::putui(tail->value->ThreadId());
			Console::puts("After Pop: Current Ready Queue:");
			for(unsigned int i = 0; i < size;++i)
			{
				
				
				Console::puts("Prev ThreadID:");
				Console::putui(loopList->prev->value->ThreadId());
				Console::puts("Current Value:");
				Console::putui(loopList->value->ThreadId());
				Console::puts(" ");
				Console::puts("Next ThreadID:");
				Console::putui(loopList->next->value->ThreadId());
				
				loopList = loopList->next;
			}
			Console::puts("\n");
			Console::puts("Size: ");
			Console::putui(size);
			Console::puts("\n");
		#endif
		return poppedThread;
	}

}
unsigned int BlockingQueue::getSize()
{
	return size;
}
BlockingQueue::ThreadList * BlockingQueue::getCurrentNode()
{
	return currentNode;
}

/*--------------------------------------------------------------------------*/
/* CONSTRUCTOR */
/*--------------------------------------------------------------------------*/

BlockingDisk::BlockingDisk(DISK_ID _disk_id, unsigned int _size) 
  : SimpleDisk(_disk_id, _size) {
	waiting_queue = new BlockingQueue();
	d_size = _size;
	d_id = _disk_id;
}

/*--------------------------------------------------------------------------*/
/* SIMPLE_DISK FUNCTIONS */
/*--------------------------------------------------------------------------*/
void BlockingDisk::issue_operation(DISK_OPERATION _op, unsigned long _block_no) {

  Machine::outportb(0x1F1, 0x00); /* send NULL to port 0x1F1         */
  Machine::outportb(0x1F2, 0x01); /* send sector count to port 0X1F2 */
  Machine::outportb(0x1F3, (unsigned char)_block_no);
                         /* send low 8 bits of block number */
  Machine::outportb(0x1F4, (unsigned char)(_block_no >> 8));
                         /* send next 8 bits of block number */
  Machine::outportb(0x1F5, (unsigned char)(_block_no >> 16));
                         /* send next 8 bits of block number */
  Machine::outportb(0x1F6, ((unsigned char)(_block_no >> 24)&0x0F) | 0xE0 | (d_id << 4));
                         /* send drive indicator, some bits, 
                            highest 4 bits of block no */

  Machine::outportb(0x1F7, (_op == READ) ? 0x20 : 0x30);

}
void BlockingDisk::read(unsigned long _block_no, unsigned char * _buf) {
  // -- REPLACE THIS!!!
  //SimpleDisk::read(_block_no, _buf);
	issue_operation(READ, _block_no);
	waiting_queue->push(Thread::CurrentThread());
	
	while(!SimpleDisk::is_ready())
	{
		SYSTEM_SCHEDULER->resume(Thread::CurrentThread());
		SYSTEM_SCHEDULER->yield();
	}
	waiting_queue->pop();
	/* read data from port */
  int i;
  unsigned short tmpw;
  for (i = 0; i < 256; i++) {
    tmpw = Machine::inportw(0x1F0);
    _buf[i*2]   = (unsigned char)tmpw;
    _buf[i*2+1] = (unsigned char)(tmpw >> 8);
  }
}


void BlockingDisk::write(unsigned long _block_no, unsigned char * _buf) {
  // -- REPLACE THIS!!!
  //SimpleDisk::write(_block_no, _buf);
	issue_operation(WRITE, _block_no);
	waiting_queue->push(Thread::CurrentThread());
	
	while(!SimpleDisk::is_ready())
	{
		SYSTEM_SCHEDULER->resume(Thread::CurrentThread());
		SYSTEM_SCHEDULER->yield();
	}
	waiting_queue->pop();

	int i; 
  	unsigned short tmpw;
  	for (i = 0; i < 256; i++) {
    	tmpw = _buf[2*i] | (_buf[2*i+1] << 8);
    	Machine::outportw(0x1F0, tmpw);
  	}
}
