# JoshuaAnderson_CSCE410

First change: I added my name to the kernel. I also added copykernel2.sh in order to account for the name change to mp1.img. Also I changed bochsrc.bxrc so the mp1.img name is booted.

Second change: I added the extra credit of MP1. Instructions for setting up GDB. Removed Everything and placed it in the MP1 directory. The mp1.zip file in the folder MP1_Sources contains everything turned into ecampus.

Third change: I added everything needed for MP2.

Fourth change: I added everything needed for MP3. If it needs to be ran in gdb the appropriate line in bochsrc.bxrc just needs to be added.
I also commented out all of the console print statements in the cont frame pool that were used to make sure the cont frame pool was working properly.

Fifth change: Added the zip I turned in on ecampus for MP3 to MP3

Sixth change: Added MP4

Seventh: Added MP5

Eighth : Added ecampus submission for MP5
