/*
 File: scheduler.C
 
 Author:
 Date  :
 
 */

/*--------------------------------------------------------------------------*/
/* DEFINES */
/*--------------------------------------------------------------------------*/

/* -- (none) -- */

/*--------------------------------------------------------------------------*/
/* INCLUDES */
/*--------------------------------------------------------------------------*/

#include "scheduler.H"
#include "thread.H"
#include "console.H"
#include "utils.H"
#include "assert.H"
#include "simple_keyboard.H"

/*--------------------------------------------------------------------------*/
/* DATA STRUCTURES */
/*--------------------------------------------------------------------------*/

/* -- (none) -- */

/*--------------------------------------------------------------------------*/
/* CONSTANTS */
/*--------------------------------------------------------------------------*/

/* -- (none) -- */

/*--------------------------------------------------------------------------*/
/* FORWARDS */
/*--------------------------------------------------------------------------*/

/* -- (none) -- */

/*--------------------------------------------------------------------------*/
/* METHODS FOR CLASS   S c h e d u l e r  */
/*--------------------------------------------------------------------------*/
//#define Debug
Scheduler::SchedQueue::SchedQueue()
{
	currentNode = NULL;
	tail = NULL;
	size = 0;
}
Scheduler::SchedQueue::~SchedQueue()
{
	delete currentNode;
	delete tail;
}
Scheduler::SchedQueue::ThreadList::ThreadList(Thread* val)
{
	next = NULL;
	prev = NULL;
	value = val;
}
void Scheduler::SchedQueue::setSize(unsigned int size_in)
{
	size = size_in;
}
Scheduler::SchedQueue::ThreadList * Scheduler::SchedQueue::getTail()
{
	return tail;
}
void Scheduler::SchedQueue::setCurrentNode(Scheduler::SchedQueue::ThreadList * newNode)
{
	currentNode = newNode;
}
void Scheduler::SchedQueue::setTail(Scheduler::SchedQueue::ThreadList * newTail)
{
	tail = newTail;
}

void Scheduler::SchedQueue::push(Thread* pushThread)
{
	if(pushThread == NULL)
	{
		Console::puts("Error on push(Thread* pushThread). Tried to push a NULL thread");
		return;
	}
	else	
	{
		if(size == 0)
		{
			
			currentNode = new ThreadList(pushThread);
			tail = currentNode;
			++size;
			#ifdef Debug
			ThreadList *loopList = currentNode;
			Console::puts("Current Tail:");
			Console::putui(tail->value->ThreadId());
			Console::puts("Current Ready Queue:");
			for(unsigned int i = 0; i < size;++i)
			{
				
				Console::puts("Prev ThreadID:");
				Console::putui(loopList->prev->value->ThreadId());
				Console::puts("Current Value:");
				Console::putui(loopList->value->ThreadId());
				Console::puts(" ");
				Console::puts("Next ThreadID:");
				Console::putui(loopList->next->value->ThreadId());
				
				loopList = loopList->next;
			}
			Console::puts("\n");
			Console::puts("Size: ");
			Console::putui(size);
			Console::puts("\n");
			#endif
		}
		else
		{
			
			ThreadList * newTail = new ThreadList(pushThread);
			ThreadList * oldTail = tail;

			oldTail->next = newTail;
			newTail->prev = oldTail;

			tail = newTail;
			++size;
						


			/*ThreadList newNode = ThreadList(pushThread);
			tail->next = &newNode;
			ThreadList *newPrev = tail; // points to old tail
			//After next line Tail becomes the pushed Thread
			tail = tail->next;
			// Set the previous thread of the new tail to the old tail
			tail->prev = newPrev;
			//Increment the size of the queue
			++size;*/

			#ifdef Debug
			ThreadList *loopList = currentNode;
			Console::puts("Current Tail:");
			Console::putui(tail->value->ThreadId());
			Console::puts("After Push: Current Ready Queue:");
			for(unsigned int i = 0; i < size;++i)
			{
				
				
				Console::puts("Prev ThreadID:");
				Console::putui(loopList->prev->value->ThreadId());
				Console::puts("Current Value:");
				Console::putui(loopList->value->ThreadId());
				Console::puts(" ");
				Console::puts("Next ThreadID:");
				Console::putui(loopList->next->value->ThreadId());
				
				loopList = loopList->next;
			}
			Console::puts("\n");
			Console::puts("Size: ");
			Console::putui(size);
			Console::puts("\n");
			#endif
		}
	}
}
Thread * Scheduler::SchedQueue::pop()
{
	if(size == 0)
	{
		Console::puts("Error on pop(). No Threads in Queue.");
	}
	else if(size == 1)
	{
		Thread * poppedThread = currentNode->value;
		tail = NULL;
		//delete currentNode;
		currentNode = NULL;
		size = 0;
		#ifdef Debug
			ThreadList *loopList = currentNode;
			Console::puts("Current Tail:");
			Console::putui(tail->value->ThreadId());
			Console::puts("After Pop ERROR SIZE IS ZERO: Current Ready Queue:");
			for(unsigned int i = 0; i < size;++i)
			{
				
				
				Console::puts("Prev ThreadID:");
				Console::putui(loopList->prev->value->ThreadId());
				Console::puts("Current Value:");
				Console::putui(loopList->value->ThreadId());
				Console::puts(" ");
				Console::puts("Next ThreadID:");
				Console::putui(loopList->next->value->ThreadId());
				
				loopList = loopList->next;
			}
			Console::puts("\n");
			Console::puts("Size: ");
			Console::putui(size);
			Console::puts("\n");
			#endif
			return poppedThread;
	}
	else
	{
		Thread* poppedThread = currentNode->value;
		currentNode = currentNode->next; //TODO::MUST FREE THE MEMORY WHEN POSSIBLE
		//delete currentNode->prev;
		currentNode->prev = NULL;
		--size;
		#ifdef Debug
			ThreadList *loopList = currentNode;
			Console::puts("Current Tail:");
			Console::putui(tail->value->ThreadId());
			Console::puts("After Pop: Current Ready Queue:");
			for(unsigned int i = 0; i < size;++i)
			{
				
				
				Console::puts("Prev ThreadID:");
				Console::putui(loopList->prev->value->ThreadId());
				Console::puts("Current Value:");
				Console::putui(loopList->value->ThreadId());
				Console::puts(" ");
				Console::puts("Next ThreadID:");
				Console::putui(loopList->next->value->ThreadId());
				
				loopList = loopList->next;
			}
			Console::puts("\n");
			Console::puts("Size: ");
			Console::putui(size);
			Console::puts("\n");
		#endif
		return poppedThread;
	}

}
unsigned int Scheduler::SchedQueue::getSize()
{
	return size;
}
Scheduler::SchedQueue::ThreadList * Scheduler::SchedQueue::getCurrentNode()
{
	return currentNode;
}
Scheduler::Scheduler() {
  //assert(false);
	readyQueue = new SchedQueue();
  	Console::puts("Constructed Scheduler.\n");
}

void Scheduler::yield() {
	
	if(readyQueue->getSize() != 0)
	{
		Thread::dispatch_to(readyQueue->pop());
	}
	else
	{
		Console::puts("yield() complete. ReadyQueue empty");
	}
}

void Scheduler::resume(Thread * _thread) {
	/*if(readyQueue->getCurrentNode()->value == _thread)
	{
		readyQueue->pop();
	}
 	readyQueue->push(_thread);*/
	
	readyQueue->push(_thread);
}

void Scheduler::add(Thread * _thread) {
  resume(_thread);
}

void Scheduler::terminate(Thread * _thread) {
		Scheduler::SchedQueue::ThreadList * currentLoc = readyQueue->getCurrentNode();
		unsigned int tempSize = readyQueue->getSize();
		for(unsigned int i = 0; i < tempSize;++i)
		{
			if(currentLoc->value == _thread)
			{
				Scheduler::SchedQueue::ThreadList * leftSide = currentLoc->prev;
				Scheduler::SchedQueue::ThreadList * rightSide = currentLoc -> next;
				if(readyQueue->getSize() == 1)
				{
					readyQueue->setCurrentNode(NULL);
					readyQueue->setTail(NULL);
					readyQueue->setSize(0);
					break;
				}
				else if(currentLoc == readyQueue->getCurrentNode())
				{
					readyQueue->setCurrentNode(readyQueue->getCurrentNode()->next);
					readyQueue->getCurrentNode()->prev = NULL;
					delete currentLoc;
					currentLoc = readyQueue->getCurrentNode();
					readyQueue->setSize((readyQueue->getSize()) - 1);
				}
				else if(currentLoc == readyQueue->getTail())
				{
					readyQueue->setTail(readyQueue->getTail()->prev);
					readyQueue->getTail()->next = NULL;
					readyQueue->setSize((readyQueue->getSize()) - 1);
					delete currentLoc;
					break;
				}
				else
				{
					Scheduler::SchedQueue::ThreadList * left = currentLoc->prev;
					Scheduler::SchedQueue::ThreadList * right = currentLoc->next;
					left->next = right;
					right->prev = left;
					delete currentLoc;
					currentLoc = left;
					readyQueue->setSize((readyQueue->getSize()) - 1);
				}
				
				
			}
			currentLoc = currentLoc->next; 
		}
}
