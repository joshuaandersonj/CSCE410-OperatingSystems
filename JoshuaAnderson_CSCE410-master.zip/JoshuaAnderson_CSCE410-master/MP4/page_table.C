#include "assert.H"
#include "exceptions.H"
#include "console.H"
#include "paging_low.H"
#include "page_table.H"
list_vm::list_vm()
{
	next = NULL;
	previous = NULL;
	dataMember = NULL;
}
list_vm::list_vm(VMPool* data)
{
	dataMember = data;
	next = NULL;
	previous = NULL;
}
list_vm::list_vm(VMPool* data, list_vm* previous)
{
	dataMember = data;
	this->previous = previous;
}
void list_vm::push(VMPool* data)
{
	list_vm *a = this; 
	if(a->dataMember == NULL)
	{
		dataMember = data;
		return;
	}
	else
	{
		while(a->next != NULL)
		{
			a = next;
		}
		list_vm b = list_vm(data,a);
		a->next = &b;
		return;	
	}
	
}
bool list_vm::remove(VMPool* data)
{
	if(data == NULL)
	{
		return false;
	}
	list_vm* a = this;
	while((a != NULL) && (data != a->dataMember))
	{
		a ->next;
	}
	if(a == NULL)
	{
		return false;
	}
	else
	{
		list_vm * prev = a->previous;
		list_vm * next = a->next;
		prev->next = next;
		next->previous = prev;
		
		return true;		
	}
}
PageTable * PageTable::current_page_table = NULL;
unsigned int PageTable::paging_enabled = 0;
ContFramePool * PageTable::kernel_mem_pool = NULL;
ContFramePool * PageTable::process_mem_pool = NULL;
unsigned long PageTable::shared_size = 0;


void PageTable::init_paging(ContFramePool * _kernel_mem_pool,
                            ContFramePool * _process_mem_pool,
                            const unsigned long _shared_size)
{
	Console::puts("Initialized Paging System\n");
	kernel_mem_pool = _kernel_mem_pool;
	process_mem_pool = _process_mem_pool;
	shared_size = _shared_size;
}

PageTable::PageTable()
{
    Console::puts("Constructed Page Table object\n");
	
	// Frame # * 4096
	vm_pool = list_vm();
	page_directory = (unsigned long*) (process_mem_pool->get_frames(1)*PAGE_SIZE);
	unsigned long * page_table = (unsigned long*)(process_mem_pool->get_frames(1)*PAGE_SIZE);
	unsigned long address = 0;
	// Fill 13th bit onward OR 011 = (Address) 0000 0000 0011
	// Direct mapped Present R/W Page entries
	for(unsigned int i = 0; i< ENTRIES_PER_PAGE;++i)
	{
		page_table[i] = address | 3; // supervisor level, r/w, present (3 = 011)
		address = address + PAGE_SIZE;
	}
	// first entry in page directory is the direct mapped memory
	page_directory[0] = (unsigned long)page_table;
	page_directory[0] = page_directory[0] | 3; // supervisor level, r/w, present (3 = 011)
	
	// Fill the rest of the page table directory with non-present R/W page table page addresses
	//(Virtual Memory)
	for(int i = 1; i< 1024; ++i)
	{
		page_directory[i] = 0 | 2; //supervisor level, r/w, not present (010)
	}
	page_directory[1023] = (unsigned long) page_directory | 3;
	num_pools = 0;
}


void PageTable::load()
{
    Console::puts("Loaded page table\n");
	current_page_table = this;
	write_cr3((unsigned long) (current_page_table->page_directory));
	
}

void PageTable::enable_paging()
{
    Console::puts("Enabled paging\n");
	write_cr0(read_cr0() | 0x80000000);
	paging_enabled = 1;
}

void PageTable::handle_fault(REGS * _r)
{
	
	unsigned long * page_dir = (unsigned long*)read_cr3(); //page table directory address
	unsigned int error_code = _r ->err_code; 
	unsigned long address = read_cr2(); // address that caused the page fault
	Console::putui(current_page_table->num_pools);
	//checks the last bit, 0 = page not present, 1 = protection fault
	if(!((_r->err_code) & 1))
	{
		list_vm checkValidAddr = current_page_table->vm_pool;
		for(unsigned int i = 0;i<current_page_table->num_pools;++i)
		{
			if(!checkValidAddr.dataMember->is_legitimate(address))
			{
				Console::putui(i);
				Console::puts("Address provided is not legitimate. In Fault\n");
				return;
			}
			else
			{
				Console::putui(i);
			}
			checkValidAddr = *(checkValidAddr.next);
		}
		// is the present bit of the page directory page set?
		//If it is NOT the page fault is in the directory itself and a page needs to be allocated
		
		unsigned long page_dir_num = (address >> 22); // |X|
		if(!(page_dir[page_dir_num] & 1)) 
		{
			 //Grab a frame and put it in the directory (allocate the page table)
			page_dir[page_dir_num] = (unsigned long)(process_mem_pool->get_frames(1) * PAGE_SIZE);
			page_dir[page_dir_num] |= 3; //Give present, r/w, supervisor 
			unsigned long page_tab_addr_temp = (unsigned long)(page_dir[page_dir_num] >> 12); //shifting out the book keeping info
			unsigned long* page_tab_addr = (unsigned long*)(page_tab_addr_temp << 12);
			//give everything in the page table,  user, R/W, Not present by default
			for(int i = 0; i<1024;++i)
			{
				//User, R/W, Not present
				page_tab_addr[i] |= 6; // 0110
			}
			unsigned long page_table_frame_no = ((address >> 12) & 1023);
			//Is it kernel or user memory?
			if((_r->err_code) & 4)
			{
			//user, R/W, present
			page_tab_addr[page_table_frame_no] = (process_mem_pool->get_frames(1)*PAGE_SIZE) | 3;
			}
			else
			{
			//supervisor, R/W , Present
			page_tab_addr[page_table_frame_no] = (process_mem_pool->get_frames(1)*PAGE_SIZE) | 9;
			}
			
		}
		// else the page fault is in the page table, not the directory
		else
		{
			unsigned long page_tab_addr_temp = page_dir[page_dir_num] >> 12; //shifting out book keeping
			unsigned long* page_tab_addr = (unsigned long*)(page_tab_addr_temp << 12);//shift back to get the page table address
			//shift out book keeping and keep only the 10 bits corresp. to page number
			unsigned long page_table_frame_no = ((address >> 12) & 1023);
			//Allocate a page and put its address at the page number corresp. in the address
			// and put the book keeping in place
			if((_r->err_code) & 4)
			{
			//user, R/W, present
			page_tab_addr[page_table_frame_no] = (process_mem_pool->get_frames(1)*PAGE_SIZE) | 3;
			}
			else
			{
			//supervisor, R/W , Present
			page_tab_addr[page_table_frame_no] = (process_mem_pool->get_frames(1)*PAGE_SIZE) | 9;
			}
		}
			
	}
	else
	{
		Console::puts("Protection Fault");
	}
	Console::puts("handled page fault\n");
}

void PageTable::register_pool(VMPool * _vm_pool)
{
    vm_pool.push(_vm_pool);
	++num_pools;
    
}

void PageTable::free_page(unsigned long _page_no) {
	//unsigned long * pageTablePage = (unsigned long*) ((_page_no >> 12 << 2) | 0xFFC00000);//1023|x|y|00|
	list_vm checkValidAddr = current_page_table->vm_pool;
		for(unsigned int i = 0;i<current_page_table->num_pools;++i)
		{
			if(!checkValidAddr.dataMember->is_legitimate(_page_no))
			{
				Console::puts("Address provided is not legitimate.\n");
				return;
			}
			checkValidAddr = *(checkValidAddr.next);
		}
	unsigned long *pageDir = current_page_table->page_directory;
	unsigned long *pageTab = (unsigned long*)pageDir[_page_no >> 22];
	unsigned long *reqPage = (unsigned long*)pageTab[((_page_no << 10) >> 22)];
	reqPage[0] = reqPage[0] | 2; // Set to not present
	process_mem_pool->release_frames(reqPage[0] / PAGE_SIZE); //release the frame in the pool
	/*unsigned long realFrameNo = _page_no >> 12;
	*pageTablePage = 0;*/
	//process_mem_pool->release_frames(realFrameNo);
	//I think this flushes the TLB?
	write_cr3((unsigned long) (current_page_table->page_directory));
    Console::puts("freed page\n");
}
