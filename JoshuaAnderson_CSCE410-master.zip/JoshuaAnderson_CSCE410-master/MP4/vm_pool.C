/*
 File: vm_pool.C
 
 Author:
 Date  :
 
 */

/*--------------------------------------------------------------------------*/
/* DEFINES */
/*--------------------------------------------------------------------------*/

/* -- (none) -- */

/*--------------------------------------------------------------------------*/
/* INCLUDES */
/*--------------------------------------------------------------------------*/

#include "vm_pool.H"
#include "console.H"
#include "utils.H"
#include "assert.H"
#include "simple_keyboard.H"
#include "page_table.H"
/*--------------------------------------------------------------------------*/
/* DATA STRUCTURES */
/*--------------------------------------------------------------------------*/

/* -- (none) -- */

/*--------------------------------------------------------------------------*/
/* CONSTANTS */
/*--------------------------------------------------------------------------*/

/* -- (none) -- */

/*--------------------------------------------------------------------------*/
/* FORWARDS */
/*--------------------------------------------------------------------------*/

/* -- (none) -- */

/*--------------------------------------------------------------------------*/
/* METHODS FOR CLASS   V M P o o l */
/*--------------------------------------------------------------------------*/

VMPool::VMPool(unsigned long  _base_address,
               unsigned long  _size,
               ContFramePool *_frame_pool,
               PageTable     *_page_table) {
    base_address = _base_address;
	size = _size;
	frame_pool = _frame_pool;
	page_table = _page_table;
	
	page_table->register_pool(this);
	num_pages = size / 4096;
    Console::puts("Constructed VMPool object.\n");
}

unsigned long VMPool::allocate(unsigned long _size) {
    unsigned int num_pages_to_allocate = _size/4096;
	num_pages_to_allocate += (_size % 4096) > 0 ? 1 : 0;
	unsigned int headCheck = num_pages_to_allocate;
//Head = 2
//alloc = 1
//free = 0
	int i = 0;
	int j = 0;
	
	while(num_pages_to_allocate != 0)
	{
		if(charMap[i] == 0)
		{
			if(num_pages < i+num_pages_to_allocate)
			{
				Console::puts("No room in virtual memory pool to allocated request size\n");
				return 0xFFFFFFFF;
			}
			j = i+1;
			
			while((charMap[j] == 0) && (j != num_pages_to_allocate))
			{
				++j;
				
			}
			if(j-i == num_pages_to_allocate)
			{
				charMap[i] = 2;
				unsigned int k = i+1;
				while(j-i > k)
				{
					charMap[k] = 1;
					++k;
				}
				 Console::puts("Allocated region of memory.\n");
				return (i*4096) + base_address;
			}
			else
			{
				j = 0;
			}
		}
		++i;
	}
	Console::puts("failed to allocate a region of virtual memory.\n");
   
}

void VMPool::release(unsigned long _start_address) {
	unsigned long startMap = (unsigned long)((_start_address-base_address)/4096);
	unsigned long curr_free_addr = _start_address;
	while(charMap[startMap] != 0)
	{
		page_table->free_page(curr_free_addr);
   		charMap[startMap] = 0;
		++startMap;
		curr_free_addr += 4096;		
	} 
    Console::puts("Released region of memory.\n");
}

bool VMPool::is_legitimate(unsigned long _address) {
	Console::putui(base_address);
	Console::putui(size);
	Console::putui(num_pages);
    if((_address > base_address) && (_address < base_address+size))
	{
		return true;
	}
	else
	{
		return false;
	}
    Console::puts("Checked whether address is part of an allocated region.\n");
}

