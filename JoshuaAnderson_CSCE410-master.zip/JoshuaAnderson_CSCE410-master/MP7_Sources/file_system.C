/*
     File        : file_system.C

     Author      : Riccardo Bettati
     Modified    : 2017/05/01

     Description : Implementation of simple File System class.
                   Has support for numerical file identifiers.
 */

/*--------------------------------------------------------------------------*/
/* DEFINES */
/*--------------------------------------------------------------------------*/

    /* -- (none) -- */

/*--------------------------------------------------------------------------*/
/* INCLUDES */
/*--------------------------------------------------------------------------*/

#include "assert.H"
#include "console.H"
#include "file_system.H"


/*--------------------------------------------------------------------------*/
/* CONSTRUCTOR */
/*--------------------------------------------------------------------------*/

FileSystem::FileSystem() {
    Console::puts("In file system constructor.\n");
    size = 0;
	numFiles = 0;
	endInfoBlock = (unsigned int)buffer2 + 16;
	nextAlloc = 1;
}

/*--------------------------------------------------------------------------*/
/* FILE SYSTEM FUNCTIONS */
/*--------------------------------------------------------------------------*/

bool FileSystem::Mount(SimpleDisk * _disk) {
    Console::puts("mounting file system form disk\n");
    disk = _disk;
	disk->read(0,buffer2);
	superBlock * blockBuff3 = (superBlock*)buffer2;
	if(blockBuff3->isFileSystem == true)
	{
		Console::puts("isFileSystem:");
		Console::putui(blockBuff3->isFileSystem);
		Console::puts("\nnumFiles:");
		Console::putui(blockBuff3->numFiles);
		Console::puts("\nendInfoBlock:");
		Console::putui(blockBuff3->endInfoBlock);
		Console::puts("\nnextAlloc");
		Console::putui(blockBuff3->nextAlloc);
		Console::puts("\n");
		//assert(false);
		numFiles = blockBuff3->numFiles;
		nextAlloc = blockBuff3->nextAlloc;
		endInfoBlock = blockBuff3->endInfoBlock;
		return true;
	}
	else
	{
		blockBuff3->numFiles = 0;
		blockBuff3->nextAlloc = 1;
		blockBuff3->endInfoBlock = 16;
		blockBuff3->isFileSystem = true;
		disk->write(0,buffer2);
		return false;
	}
}

bool FileSystem::Format(SimpleDisk * _disk, unsigned int _size) {
    Console::puts("formatting disk\n");
	_disk->read(0,buffer2);
	superBlock * blockBuff3 = (superBlock*) buffer2; 
	blockBuff3->numFiles = 0;
	blockBuff3->nextAlloc = 1;
	blockBuff3->endInfoBlock = 16;
	blockBuff3->isFileSystem = true;
	_disk->write(0,buffer2);
	return true;
}

File * FileSystem::LookupFile(int _file_id) {
    Console::puts("looking up file\n");
	disk->read(0,buffer2);
    superBlock * blockBuff3 = (superBlock*)buffer2;
	unsigned int travelDistance = 16;
	unsigned short * addr =(unsigned short*) buffer2 + travelDistance;
	while(addr[0] != _file_id && travelDistance != endInfoBlock)
	{
		addr += 4;
		travelDistance += 4;
	}
	if(addr[0] == _file_id)
	{
		File * file = new File();
		file->f_id = _file_id;
		file->startingBlock = addr[1];
		return file;
	}
	else
	{
		return NULL;
	}
	
}

bool FileSystem::CreateFile(int _file_id) {
    Console::puts("creating file\n");
   	File *nFile = new File();
	nFile->f_id = _file_id;
	if(LookupFile(_file_id))
	{
		return false;	
	}
	else
	{
		disk->read(0,buffer2);
		superBlock * blockBuff3 = (superBlock*)buffer2;
		unsigned char * addr = buffer2 + endInfoBlock;
	 	addr[0] = nFile->f_id;
		endInfoBlock += 4;
		return true;
	}
}

bool FileSystem::DeleteFile(int _file_id) {
    Console::puts("deleting file\n");
     Console::puts("looking up file\n");
	disk->read(0,buffer2);
    superBlock * blockBuff3 = (superBlock*)buffer2;
	unsigned int travelDistance = 16;
	unsigned short * addr =(unsigned short*) buffer2 + travelDistance;
	while(addr[0] != _file_id && travelDistance != endInfoBlock)
	{
		addr += 4;
		travelDistance += 4;
	}
	if(addr[0] == _file_id && travelDistance != BLOCKSIZE)
	{
		unsigned int locsToReplace = (endInfoBlock - travelDistance)/4;
		unsigned int i = 0;
		while(locsToReplace != 0)
		{
			addr[i] = addr[i+2];
			addr[i+1] = addr[i+3];
			locsToReplace -= 4;
		}
		disk->write(0,buffer2);
		return true;
	}
	return false;
}
bool FileSystem::allocateBlock(unsigned int _block_no)
{
	disk->read(_block_no,buffer2);
	if(blockBuff2->available == 1)
	{
		return false;
	}
	else
	{
		memset(buffer2,0,BLOCKSIZE);
		blockBuff2->available = 1;
		blockBuff2->nextBlock = _block_no;
		disk->write(_block_no,buffer2);
		return true;
	}	
}
bool FileSystem::deallocateBlock(unsigned int _block_no)
{
	memset(buffer2,0,BLOCKSIZE);
	if(_block_no >= (size/512))
	{
		Console::puts("Error in deallocateBlock. _block_no is >= Largest Block Num.");
		return false;
	}
	else
	{
		disk->write(_block_no,buffer2);
		return true;
	}
}
bool FileSystem::removeStartingBlock(unsigned int _file_id)
{
	disk->read(0,buffer2);
	superBlock * blockBuffer3 = (superBlock*)buffer2;
	unsigned int travelDistance = 16;
	unsigned short * addr =(unsigned short*) buffer2;
	addr += travelDistance;
	while( (addr[0] != _file_id) && (travelDistance != endInfoBlock) )
	{
		travelDistance += 4;
		addr +=4;
	}
	if(addr[0] == _file_id)
	{		
		Console::puts("Orig starting block disk value:");
		Console::putui(addr[1]);
		addr[1] = 0;
		return true;
	}
	return false;
}
bool FileSystem::storeStartingBlock(unsigned int _file_id, unsigned int startingBlock)
{
	disk->read(0,buffer2);
	superBlock * blockBuffer3 = (superBlock*)buffer2;
	unsigned int travelDistance = 16;
	unsigned short * addr = (unsigned short*)buffer2;
	addr += travelDistance;
	while( (addr[0] != _file_id) && (travelDistance != endInfoBlock) )
	{
		travelDistance += 4;
	}
	if(addr[0] == _file_id)
	{		
		Console::puts("Orig starting block disk value:");
		Console::putui(addr[1]);
		addr[1] = startingBlock;
		return true;
	}
	return false;
}
