/*
     File        : file.C

     Author      : Riccardo Bettati
     Modified    : 2017/05/01

     Description : Implementation of simple File class, with support for
                   sequential read/write operations.
*/

/*--------------------------------------------------------------------------*/
/* DEFINES */
/*--------------------------------------------------------------------------*/

    /* -- (none) -- */

/*--------------------------------------------------------------------------*/
/* INCLUDES */
/*--------------------------------------------------------------------------*/

#include "assert.H"
#include "console.H"
#include "file.H"

/*--------------------------------------------------------------------------*/
/* CONSTRUCTOR */
/*--------------------------------------------------------------------------*/

File::File() {
    /* We will need some arguments for the constructor, maybe pointer to disk
     block with file management and allocation data. */
    Console::puts("In file constructor.\n");
	
	f_id = 0;
	f_size = 0;
	curr_block = 0;
	curr_byte = 0;
	startingBlock = 0;
}
File::File(unsigned int _f_id)
{
	
	Console::puts("In file constructor.\n");
	f_id = _f_id;
	File * tempFile = FILE_SYSTEM->LookupFile(f_id);
	if(tempFile)
	{
		Console::puts("File Located on Disk");
		*this = *tempFile;
	}
	else if(FILE_SYSTEM->CreateFile(f_id)) {
		f_size = 0;
		curr_block = 0;
		curr_byte = 0;
		startingBlock = 0;
	}

}

/*--------------------------------------------------------------------------*/
/* FILE FUNCTIONS */
/*--------------------------------------------------------------------------*/

int File::Read(unsigned int _n, char * _buf) {
    Console::puts("reading from file\n");
	unsigned int n = _n;
	unsigned int charsRead = 0;
    if(this->startingBlock != 0)
	{
		FILE_SYSTEM->disk->read(curr_block,buffer);
		unsigned int num_bytes_left_in_file = f_size - (curr_block_num*DATASIZE) - curr_byte;
		if(num_bytes_left_in_file > n)
		{
		  //Read till n runs out
			while((n != 0) && (!this->EoF())) 
			{	
		    	if(n > DATASIZE - curr_byte)
				{
			  memcpy((void*)_buf + charsRead,(void*) buffer + curr_byte + 16, DATASIZE-curr_byte);
			  charsRead += DATASIZE-curr_byte;
			  n -= DATASIZE-curr_byte;
			  		if(blockBuff->nextBlock == curr_block)
			    	{
			      		Console::puts("Error in read. Could not find the next block to read from");
			     		 curr_byte = DATASIZE;
			    		  return charsRead;
			   		 }
			  		else
			    	{
			      		curr_byte = 0;
			      		curr_block = blockBuff->nextBlock;
			      		++curr_block_num;
			    	}
				}
		    	else
				{
			  		memcpy((void*) _buf + charsRead, (void*) buffer + curr_byte + 16, n);
			  		charsRead += n;
			  		n = 0;
			  		curr_byte += n;
			  		if(DATASIZE-curr_byte == 0)
			    	{
			      		curr_byte =0;
			      		curr_block = blockBuff->nextBlock;
			      		++curr_block_num;
			    	}
					
				}
		    }
		}
		else //Read till eof
		{
			while(!this->EoF())
			{
				if(n > DATASIZE - curr_byte)
				{
			    	memcpy((void*) _buf + charsRead, (void*) buffer + curr_byte + 16, DATASIZE-curr_byte);
			    	charsRead += (DATASIZE-curr_byte);
			    	n -= (DATASIZE-curr_byte);
			    	curr_byte = 0;
			    	curr_block = blockBuff->nextBlock;
			    	++curr_block_num;
			    }
			  	else
			    {
			    	memcpy((void*) _buf + charsRead,(void*) buffer + curr_byte + 16, n);
			      	charsRead += n;
			      	n = 0;
			      	curr_byte += n;
					
			    }
			}
		
		return charsRead;
		}
	}
	else
	{
		return 0;
	}
}

unsigned int File::getBlock()
{
	if(FILE_SYSTEM->nextAlloc == 0)
	{
		Console::puts("Error on getBlock. nextAlloc == 0");
		assert(false);
	}
	unsigned int next_block = FILE_SYSTEM->nextAlloc;
	while(true)
	{
		if(next_block >= (FILE_SYSTEM->size)/512)
		{
			next_block = 1;
		}
		if(FILE_SYSTEM->allocateBlock(next_block))
		{
			if(startingBlock == 0)
			{
				FILE_SYSTEM->storeStartingBlock(f_id,startingBlock);
			}
			FILE_SYSTEM->nextAlloc = next_block + 1;
			return next_block;
		}
		++next_block;		
	}
	return 0;	
	
}

void File::Write(unsigned int _n, const char * _buf) {
    Console::puts("writing to file\n");
    /*unsigned int f_size; //File size in bytes
	unsigned int num_blocks;
	unsigned int curr_block_num; //Which logical block number is being read from
	unsigned int curr_block; //Next record to be written/read from
	unsigned int curr_byte; //Next byte to be written/read from
	unsigned int startingBlock;*/
	if(startingBlock == 0)
	{
		if(_n == 0)
			return;
		startingBlock = this->getBlock();
	}
	unsigned int n = _n;
	void * write_ptr = (void*)(buffer + curr_byte + 16);
	void * src_ptr = (void*)_buf;
	unsigned int curr_write_space = DATASIZE-curr_byte;
	while(n != 0)
	{	
		unsigned int curr_block_loop = curr_block;
		FILE_SYSTEM->disk->read(curr_block,buffer);
		memcpy(write_ptr,src_ptr,(curr_write_space < n ? DATASIZE-curr_byte:n));
		if(curr_write_space < n)
		{
			if(blockBuff->nextBlock == curr_block)
			{
				blockBuff->nextBlock = this->getBlock(); 
				if(f_size / DATASIZE == num_blocks)
				{
						
				}
				else
				{
					f_size += curr_write_space;	
				}
				++num_blocks;
				
			}
			n -= curr_write_space;
			++curr_block_num;
			curr_byte = 0;
			curr_write_space = DATASIZE;
			curr_block = blockBuff->nextBlock;				
		}
		else
		{
			if((curr_block_num == num_blocks-1))
			{
				if( (f_size % DATASIZE) < curr_byte + n)
				{
					f_size = f_size + ( (curr_byte + n) - (f_size % DATASIZE) );
				}
				n = 0;
				curr_byte += n;
				
			}
		}
		FILE_SYSTEM->disk->write(curr_block_loop,buffer);
	}
	
}

void File::Reset() {
    Console::puts("reset current position in file\n");
    curr_block = startingBlock;
	curr_byte = 0;
	curr_block_num=0;
}

void File::Rewrite() {
    Console::puts("erase content of file\n");
    curr_block = startingBlock;
	curr_block_num = 0;
	while(curr_block_num != num_blocks)
	{
		FILE_SYSTEM->disk->read(curr_block,buffer);
		curr_block = blockBuff->nextBlock;
		memset(buffer,0,BLOCKSIZE);
		++curr_block_num;
	}
	f_size = 0;
	curr_block_num  =0;
	curr_block = 0;
	curr_byte = 0;
	startingBlock = 0;
	if(!FILE_SYSTEM->removeStartingBlock(f_id))
	{
		Console::puts("Something weird happened with removeStartingBlock");	
	}
	num_blocks = 0;
}


bool File::EoF() {
    Console::puts("testing end-of-file condition\n");
    if(startingBlock == 0 || f_size == 0 || curr_byte == DATASIZE || (((curr_block_num * DATASIZE) + curr_byte) == f_size))
	{
		return true;
	}
	return false;
}
